/**
 * Programexempel.
 */

package cslib.examples;