/**
 * Fraktaler (MandelbrotGUI).
 */

package cslib.fractal;

