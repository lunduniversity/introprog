/**
 * Labyrint (Maze).
 */

package cslib.maze;
