/**
 * Geometriska figurer och lista av figurer (Shape och ShapeList).
 */

package cslib.shapes;

