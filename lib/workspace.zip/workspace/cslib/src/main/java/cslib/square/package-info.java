/**
 * Kvadrater (Square).
 */

package cslib.square;

