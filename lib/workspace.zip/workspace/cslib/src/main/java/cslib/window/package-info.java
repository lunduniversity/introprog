/**
 * Lättanvänt stöd för att skapa ritfönster.
 *  
 * Innehåller klasserna SimpleWindow för att skapa ritfönster, 
 * samt Sprite för att skapa flyttbara bilder i ett ritfönster.
 */

package cslib.window;

