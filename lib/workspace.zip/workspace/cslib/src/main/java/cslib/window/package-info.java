/**
 * Ritfönster (SimpleWindow).
 */

package cslib.window;

