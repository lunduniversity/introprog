//> using scala "3"
//> using dep "net.kogics:kojo-lib:0.2.0,url=https://github.com/lunduniversity/introprog/releases/download/kojo-lib-0.2.0/kojo-lib-0.2.0.jar"

export net.kogics.kojo.Swedish.*, padda.*, CanvasAPI.*, TurtleAPI.*
