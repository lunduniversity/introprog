public class Hi {
    public static void main(String[] args) {
        System.out.println("Hej Java-app!");
    }
}
