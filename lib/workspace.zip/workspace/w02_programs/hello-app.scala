object Hello {
  def main(args: Array[String]): Unit = {
    println("Hej scala-app!")
  }
}
