//> using scala 3.3

@main def run = println("Hej Scala-app!") // en @main-funktion

object Hello;
  def main(args: Array[String]): Unit = // en primitiv main-metod måste finnas i ett objekt
    println("Hej Scala-app med primitiv main!")
