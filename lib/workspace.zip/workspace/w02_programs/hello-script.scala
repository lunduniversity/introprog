println("hejsan script")
