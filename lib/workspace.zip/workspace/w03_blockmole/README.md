# Laboration W03 blockmole

Laboration blockmole utvecklar du helt från början med en kodeditor och kompilering i terminalen.
Därför finns inget kodskellett till denna veckas labb. Du hittar laborationsuppgifterna i kompendiet:
http://cs.lth.se/pgk/kompendium

Filen hello-simplewindow.scala kan du använda för prova kompilering med en jar-fil på classpath.
Ladda ner cslib.jar härifrån: http://cs.lth.se/pgk/cslib

Kompilera i linuxterminal med detta kommando: 

    scalac -cp "cslib.jar:." hello-simplewindow.scala

Kör i linuxterminal med detta kommando: 

    scala -cp "cslib.jar:." hello.scala

Om du kör i Windows Powershell eller Cmd byt kolon mot semikolon i kommandona ovan.
