# Irritext

Här finns ett exempel på en början till ett lagom irriterande textspel.
Ladda ner `irritext.scala` och kör igång med:

    >sbt
    sbt> ~run
