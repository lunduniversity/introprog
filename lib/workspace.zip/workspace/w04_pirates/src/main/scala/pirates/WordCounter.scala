package pirates

/** Sparar olika ord och räknar antalet förekomster. */
class WordCounter {

  /** Lägger till ordet word och räknar upp antalet förekomster. */
  def addWord(word: String): Unit = ???

  /** Ger det vanligaste ordet och antalet förekomster. */
  def mostCommonWord: (String, Int) = ???

  /** Skriver ut det vanligaste ordet och dess antal*/
  override def toString(): String = ???
}
