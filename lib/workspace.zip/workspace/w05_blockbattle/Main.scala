object Main {
  def main(args: Array[String]): Unit = {
    println("TODO: blockbattle")
  }
}
