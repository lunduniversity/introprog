mkdir -p lib
wget -O lib/cslib.jar http://cs.lth.se/pgk/cslib
