echo scala -cp "lib/cslib.jar:bin" graphics.Main
scala -cp "lib/cslib.jar:bin" graphics.Main
