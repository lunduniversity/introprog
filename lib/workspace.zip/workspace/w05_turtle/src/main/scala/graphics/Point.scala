package graphics

case class Point(x: Double, y: Double) 
