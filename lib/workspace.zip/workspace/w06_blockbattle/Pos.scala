package blockbattle

case class Pos(x: Int, y: Int) {
  def moved(delta: (Int, Int)): Pos = ???
}
