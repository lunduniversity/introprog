//> using scala 3.5
//> using option -unchecked -deprecation -Wunused:all -Wvalue-discard -Wsafe-init
//> using dep se.lth.cs::introprog::1.4.0
