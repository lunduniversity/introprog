//> using scala 3.3
//> using option -unchecked -deprecation -Wunused:all -Wvalue-discard -Ysafe-init
//> using dep se.lth.cs::introprog::1.3.1
