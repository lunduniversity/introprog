Skriv följande kommando för att hantera flera huvudprogram:
* `scala-cli run . --list-main-class` för att se alla huvudprogram
* `scala-cli run . --main-class cards.PokerProbability` för att köra main-metoden i PokerProbability.scala, där cards är paketnamnet.