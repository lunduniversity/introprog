Skriv följande kommando för att hantera flera huvudprogram:
* `scala run . --list-main-class` för att se alla huvudprogram
* `scala run . --main-class cards.PokerProbability` för att köra main-metoden i PokerProbability.scala, där cards är paketnamnet.