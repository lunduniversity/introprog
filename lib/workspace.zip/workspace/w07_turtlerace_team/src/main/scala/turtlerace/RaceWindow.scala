package turtlerace;
import cslib.window._

class RaceWindow {
  private val startX = ???
  private val endX = ???
  /**
   * Draws a race in the RaceWindow
   */
  def draw: Unit = ???
  
  /**
   * Returns the Y-coordinate for the turtle with start number n
   */
  def getStartY(n: Int): Int = ???
  
  /**
   * Returns the X-coordinate of the starting position
   */
  def getStartX: Int = ???
  
  /**
   * Returns the X-coordinate of the finish line
   */
  def getEndX: Int = ???
}