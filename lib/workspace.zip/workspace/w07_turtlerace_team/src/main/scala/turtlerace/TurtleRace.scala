package turtlerace;

import scala.collection.mutable.ArrayBuffer
import cslib.window._

object TurtleRace {
  /**
   * Perform a race between eight turtles and returns the turtles in finishing order
   */
  def race(turtles: Seq[RaceTurtle], rw: RaceWindow, title: String): List[RaceTurtle] = ???
}