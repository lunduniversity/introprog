package snake

class OnePlayerGame { // ska ärva SnakeGame

  // orm, äpple, ev. bananer etc

  def play(playerNames: String*): Unit = ???  // ska överskugga play i SnakeGame
}
