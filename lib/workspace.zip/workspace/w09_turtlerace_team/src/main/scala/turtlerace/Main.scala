package turtlerace

object Main {
  def main(args : Array[String]): Unit = {
    println("TODO: ColorTurtle, RaceTurtle, TurtleRace")
    println("TODO: subtypes of RaceTurtle with different properties ")
    val rw = new RaceWindow()
    val tr = new TurtleRace()
    tr.race(Seq(), rw, "TODO TurtleRace")
  }
}
