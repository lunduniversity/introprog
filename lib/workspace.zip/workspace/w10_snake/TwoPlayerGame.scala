package snake

class TwoPlayerGame:  // ska ärva SnakeGame

  // ormar och ev. äpple, bananer etc

  def play(playerNames: String*): Unit = ???  // ska överskugga play i SnakeGame
