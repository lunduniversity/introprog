package game;

public class Game {
    public Game(String playerName){

    }

    public String getPlayerName(){
        return "";
    }

    public int getScore(){
        return 0;
    }

    public void run(){
        
    }
}
