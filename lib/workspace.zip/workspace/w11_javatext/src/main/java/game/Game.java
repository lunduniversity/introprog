package game;

public class Game {
    /** Start this game. Returns true if player wants to play a new game. */
    public boolean run(){
        System.out.println("TODO");
        return false;
    }
}
