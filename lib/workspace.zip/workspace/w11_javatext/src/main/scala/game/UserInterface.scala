package game

object UserInterface {
  def readChoice(choices: Array[String]): Int = ???

  def readString(): String = ???

  def showHighScores(scores: java.util.ArrayList[Game]): Unit = ???

  def showHighScores(scores: java.util.ArrayList[Game], player: String): Unit = ???
}

