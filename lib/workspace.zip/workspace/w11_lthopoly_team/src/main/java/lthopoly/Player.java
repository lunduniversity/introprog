package lthopoly;

/**
 * Created by Tank on 4/17/2016.
 */
public class Player {

    /**
     * Creates a new player
     */
    public Player(String name, int money, int pos) {
    }

    /**
     * Returns the players money
     */
    public int getMoney() {
        return 0;
    }

    /**
     * Adjusts the players money
     */
    public void adjustMoney(int money) {
    }

    /**
     * Returns the players position
     */
    public int getPosition() {
        return 0;
    }

    /**
     * Returns a string representation of the player
     */
    @Override
    public String toString() {
        return null;
    }

    /**
     * Sets the players position
     */
    public void setPosition(int pos) {
    }
}
