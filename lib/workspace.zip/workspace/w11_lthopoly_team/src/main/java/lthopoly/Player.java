package lthopoly;

/**
 * Created by Tank on 4/17/2016.
 */
public class Player {

    /**
     * Creates a new player
     */
    public Player(String name, int money, int pos) {
    }

    /**
     * Returns this player's money
     */
    public int getMoney() {
        return 0;
    }

    /**
     * Adjusts this player's money
     */
    public void adjustMoney(int money) {
    }

    /**
     * Returns this player's position
     */
    public int getPosition() {
        return 0;
    }

    /**
     * Returns a string representation of this player
     */
    @Override
    public String toString() {
        return null;
    }

    /**
     * Sets this player's position
     */
    public void setPosition(int pos) {
    }
}
