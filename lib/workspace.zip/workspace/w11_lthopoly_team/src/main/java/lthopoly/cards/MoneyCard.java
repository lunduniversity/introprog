package lthopoly.cards;

/**
 * Created by Tank on 4/17/2016.
 */
public class MoneyCard {

    /**
     * Creates a new MoneyCard
     */
    public MoneyCard(String description, int money) {
    }

    /**
     * Returns this card's money adjustment value
     */
    public int getMoney() {
        return 0;
    }

    /**
     * Returns the description of why the money is adjusted
     */
    public String getDescription() {
        return null;
    }
}
