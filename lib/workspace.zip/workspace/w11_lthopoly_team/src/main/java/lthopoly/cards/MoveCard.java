package lthopoly.cards;

/**
 * Created by Tank on 4/17/2016.
 */
public class MoveCard {

    /**
     * Creates a new MoveCard
     */
    public MoveCard(String description, int positionAdjustment) {
    }

    /**
     * Returns the position adjustment
     */
    public int getPositionAdjustment() {
        return 0;
    }

    /**
     * Returns the description of why the position is adjusted
     */
    public String getDescription() {
        return null;
    }


}
