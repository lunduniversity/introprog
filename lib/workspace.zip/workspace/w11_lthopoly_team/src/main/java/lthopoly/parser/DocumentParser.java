package lthopoly.parser;

import lthopoly.cards.MoneyCard;
import lthopoly.cards.MoveCard;
import lthopoly.spaces.BoardSpace;

import java.util.ArrayList;

/**
 * Created by Tank on 4/17/2016.
 */
public class DocumentParser {

    /**
     * Returns an ArrayList of BoardSpaces loaded from a file
     */
    public static ArrayList<BoardSpace> getBoard() {
        return null;
    }


    /**
     * Returns an array of MoneyCards loaded from a file
     */
    public static MoneyCard[] getMoneyCards() {
        return null;
    }

    /**
     * Returns an array of MoveCards loaded from a file
     */
    public static MoveCard[] getMoveCards() {
        return null;
    }


}
