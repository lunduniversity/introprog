package lthopoly

import lthopoly._
import scala.collection.JavaConverters._


object Main {
  def main(args: Array[String]): Unit = {

  }

  /**
    * Retrieves all possible actions from GameBoard and joins them with
    * a corresponding description String into tuples.
    * The tuples are then sent to the promptForInput method in TextUI.
    *
    * @return the user's choice as given by promptForInput.
    */
  def getAction(board: GameBoard): Int = ???

}
