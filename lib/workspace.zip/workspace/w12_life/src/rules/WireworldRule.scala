package rules

import models._

// Implements the Wireworld cellular automaton.
// https://en.wikipedia.org/wiki/Wireworld
object WireworldRule extends Rule {
  def apply(m: Matrix2D, row: Int, col: Int): Int = ???
}