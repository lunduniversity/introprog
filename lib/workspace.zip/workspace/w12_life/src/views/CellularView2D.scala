package views

import models.Matrix2D

trait CellularView2D {
  def display(m: Matrix2D)
}

